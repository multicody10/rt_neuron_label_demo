\
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

@dataclass
class DatasetConfig:
    n_concepts: int = 8
    n_noise: int = 8
    seed: int = 1

class ConceptStream:
    """
    Produces a stream of inputs with named latent concepts.
    x = [concepts, noise]
    """
    def __init__(self, cfg: DatasetConfig):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)

    def sample(self, batch: int = 256):
        c = self.rng.integers(0, 2, size=(batch, self.cfg.n_concepts)).astype(np.float32)
        noise = self.rng.normal(0.0, 1.0, size=(batch, self.cfg.n_noise)).astype(np.float32)
        x = np.concatenate([c, noise], axis=1)
        return x, c
