\
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Tuple
import numpy as np
import pandas as pd

@dataclass
class AiLabelConfig:
    concept_names: List[str]
    eps: float = 1e-9

class OnlineAiNeuronLabeler:
    """
    Streaming labeling of each hidden neuron against a set of concepts.
    Maintains per neuron activation stats conditioned on concept present vs absent.
    """
    def __init__(self, cfg: AiLabelConfig, hidden: int):
        self.cfg = cfg
        self.hidden = hidden
        k = len(cfg.concept_names)

        self.n1 = np.zeros((hidden, k), dtype=np.float64)
        self.n0 = np.zeros((hidden, k), dtype=np.float64)
        self.s1 = np.zeros((hidden, k), dtype=np.float64)
        self.s0 = np.zeros((hidden, k), dtype=np.float64)

        # Pairwise for a small set of pairs
        self.pairs = [(0,1), (2,3), (4,5), (6,7)]
        self.n11 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)
        self.s11 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)
        self.n10 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)
        self.s10 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)
        self.n01 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)
        self.s01 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)
        self.n00 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)
        self.s00 = np.zeros((hidden, len(self.pairs)), dtype=np.float64)

    def update(self, h_act: np.ndarray, concepts: np.ndarray):
        h_act = np.asarray(h_act, dtype=np.float32)
        concepts = np.asarray(concepts, dtype=np.float32)
        b = h_act.shape[0]
        k = concepts.shape[1]
        assert k == len(self.cfg.concept_names)

        for j in range(k):
            mask1 = concepts[:, j] > 0.5
            mask0 = ~mask1
            if mask1.any():
                self.n1[:, j] += mask1.sum()
                self.s1[:, j] += h_act[mask1].sum(axis=0)
            if mask0.any():
                self.n0[:, j] += mask0.sum()
                self.s0[:, j] += h_act[mask0].sum(axis=0)

        for pidx, (a, b_) in enumerate(self.pairs):
            A = concepts[:, a] > 0.5
            B = concepts[:, b_] > 0.5
            m11 = A & B
            m10 = A & (~B)
            m01 = (~A) & B
            m00 = (~A) & (~B)

            if m11.any():
                self.n11[:, pidx] += m11.sum()
                self.s11[:, pidx] += h_act[m11].sum(axis=0)
            if m10.any():
                self.n10[:, pidx] += m10.sum()
                self.s10[:, pidx] += h_act[m10].sum(axis=0)
            if m01.any():
                self.n01[:, pidx] += m01.sum()
                self.s01[:, pidx] += h_act[m01].sum(axis=0)
            if m00.any():
                self.n00[:, pidx] += m00.sum()
                self.s00[:, pidx] += h_act[m00].sum(axis=0)

    def snapshot(self, top_n: int = 40) -> pd.DataFrame:
        eps = self.cfg.eps
        k = len(self.cfg.concept_names)
        rows: List[Dict[str, object]] = []

        mean_all = (self.s1.sum(axis=1) + self.s0.sum(axis=1)) / (self.n1.sum(axis=1) + self.n0.sum(axis=1) + eps)

        for i in range(self.hidden):
            # Single concept effect size
            m1 = self.s1[i] / (self.n1[i] + eps)
            m0 = self.s0[i] / (self.n0[i] + eps)
            diff = m1 - m0
            best = int(np.argmax(diff))
            conf = float(diff[best] / (np.abs(diff).sum() + eps))

            # Pair interaction score: activation should be highest in 11 vs others
            pair_scores = []
            for pidx, (a, b_) in enumerate(self.pairs):
                m11 = self.s11[i, pidx] / (self.n11[i, pidx] + eps)
                m10 = self.s10[i, pidx] / (self.n10[i, pidx] + eps)
                m01 = self.s01[i, pidx] / (self.n01[i, pidx] + eps)
                m00 = self.s00[i, pidx] / (self.n00[i, pidx] + eps)
                score = m11 - max(m10, m01, m00)
                pair_scores.append(score)
            pair_best = int(np.argmax(pair_scores))
            pair_conf = float(pair_scores[pair_best] / (np.abs(pair_scores).sum() + eps))
            pair_name = f"{self.cfg.concept_names[self.pairs[pair_best][0]]}+{self.cfg.concept_names[self.pairs[pair_best][1]]}"

            rows.append({
                "unit": i,
                "mean_act": float(mean_all[i]),
                "label_single": self.cfg.concept_names[best],
                "conf_single": conf,
                "label_pair": pair_name,
                "conf_pair": pair_conf,
            })

        df = pd.DataFrame(rows)
        df = df.sort_values(["mean_act"], ascending=False).head(top_n).reset_index(drop=True)
        return df
