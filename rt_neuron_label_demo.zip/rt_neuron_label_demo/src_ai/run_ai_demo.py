\
from __future__ import annotations

import numpy as np
from dataset import ConceptStream, DatasetConfig
from toy_model import ToyModel, ModelConfig
from online_labeler_ai import OnlineAiNeuronLabeler, AiLabelConfig

def main():
    concept_names = [f"c{j}" for j in range(8)]
    stream = ConceptStream(DatasetConfig(n_concepts=8, n_noise=8, seed=7))
    model = ToyModel(ModelConfig(n_concepts=8, n_noise=8, hidden=16, seed=7))
    labeler = OnlineAiNeuronLabeler(AiLabelConfig(concept_names=concept_names), hidden=model.cfg.hidden)

    steps = 300
    for t in range(steps):
        x, c = stream.sample(batch=256)
        h = model.forward_hidden(x)
        labeler.update(h, c)
        if t % 50 == 0:
            print(f"step {t}")
            print(labeler.snapshot(top_n=16).to_string(index=False))
            print()

if __name__ == "__main__":
    main()
