\
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

def relu(x):
    return np.maximum(x, 0.0)

@dataclass
class ModelConfig:
    n_concepts: int = 8
    n_noise: int = 8
    hidden: int = 16
    seed: int = 1

class ToyModel:
    """
    A fixed, known model with interpretable hidden units.
    Hidden units are designed to respond to:
    - single concepts
    - simple two concept interactions
    """
    def __init__(self, cfg: ModelConfig):
        self.cfg = cfg
        rng = np.random.default_rng(cfg.seed)
        d_in = cfg.n_concepts + cfg.n_noise
        h = cfg.hidden

        W = np.zeros((d_in, h), dtype=np.float32)
        b = np.zeros((h,), dtype=np.float32)

        # Units 0..7: single concept detectors
        for j in range(cfg.n_concepts):
            W[j, j] = 3.0
            b[j] = 1.5

        # Units 8..11: pair interactions (AND like)
        pairs = [(0,1), (2,3), (4,5), (6,7)]
        for i, (a, b_) in enumerate(pairs, start=cfg.n_concepts):
            W[a, i] = 2.0
            W[b_, i] = 2.0
            b[i] = 2.5

        # Remaining units: nuisance responses to noise dims
        for i in range(cfg.n_concepts + len(pairs), h):
            nd = cfg.n_concepts + (i - (cfg.n_concepts + len(pairs))) % cfg.n_noise
            W[nd, i] = 1.5
            b[i] = 0.2

        self.W = W
        self.b = b

    def forward_hidden(self, x: np.ndarray) -> np.ndarray:
        z = x @ self.W + self.b
        return relu(z)
