Real time neuron labeling demo

This is a small simulation plus online labeler that shows the core loop:
identity tracking, streaming feature extraction, streaming functional labeling, and active probing.

What it is
- A simulator that generates spike counts for many neurons with hidden true tuning
- An online labeler that assigns each neuron a label vector with confidence
- A simple console runner and an optional Streamlit dashboard

What it is not
- Not a medical device
- Not a brain interface
- Not a spike sorter for real electrode data

Requirements
Python 3.10 or newer

Quick start Windows 10
1. Open PowerShell in this folder
2. python -m venv .venv
3. .\.venv\Scripts\Activate.ps1
4. pip install -r requirements.txt
5. python src\run_console.py

Optional dashboard
streamlit run src\run_dashboard.py

Files
src\simulator.py            Synthetic neuron and state generator
src\identity_tracker.py     Stable neuron id matching from drifting features
src\online_labeler.py       Streaming label vector and confidence
src\active_prober.py        Chooses next probe to reduce label uncertainty
src\run_console.py          Console demo runner
src\run_dashboard.py        Streamlit dashboard

License
MIT

AI neuron labeling demo
python src_ai\run_ai_demo.py
