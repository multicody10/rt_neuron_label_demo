\
from __future__ import annotations

import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from simulator import NeuronSimulator, SimConfig
from identity_tracker import IdentityTracker, TrackConfig
from online_labeler import OnlineLabeler, LabelConfig
from active_prober import ActiveProber, ProbeConfig

def main():
    sim = NeuronSimulator(SimConfig(n_neurons=96, n_stim=8, n_state=4, dt_s=0.02, seed=2))
    tracker = IdentityTracker(TrackConfig(cost="cosine", max_cost=0.35, seed=2))
    labeler = OnlineLabeler(LabelConfig(n_stim=sim.cfg.n_stim, n_state=sim.cfg.n_state))
    prober = ActiveProber(ProbeConfig(n_stim=sim.cfg.n_stim, n_state=sim.cfg.n_state), rng_seed=2)

    steps = 2000
    hist = []
    for t in range(steps):
        stim = prober.choose_stim(labeler)
        state = prober.choose_state(labeler)
        movement = float(np.sin(t * 0.03) + 0.15 * np.random.randn())
        pkt = sim.step(stim, state, movement)

        stable_ids = tracker.match(pkt["features"])
        labeler.update(stable_ids, pkt["spikes"], stim, state, movement, sim.cfg.dt_s)

        if t % 100 == 0:
            snap = labeler.snapshot(top_n=12)
            print(f"step {t:4d} stim {stim} state {state} movement {movement:+.2f}")
            if not snap.empty:
                print(snap.to_string(index=False))
            print()

        if t % 10 == 0:
            snap = labeler.snapshot(top_n=10)
            if not snap.empty:
                hist.append({
                    "t": t * sim.cfg.dt_s,
                    "mean_stim_conf": float(snap["stim_conf"].mean()),
                    "mean_state_conf": float(snap["state_conf"].mean()),
                })

    df = pd.DataFrame(hist)
    if not df.empty:
        plt.figure()
        plt.plot(df["t"], df["mean_stim_conf"])
        plt.xlabel("time s")
        plt.ylabel("mean stim confidence")
        plt.title("label confidence over time")
        plt.tight_layout()
        plt.show()

if __name__ == "__main__":
    main()
