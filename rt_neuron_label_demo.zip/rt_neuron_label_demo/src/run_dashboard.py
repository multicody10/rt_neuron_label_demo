\
from __future__ import annotations

import time
import numpy as np
import pandas as pd
import streamlit as st

from simulator import NeuronSimulator, SimConfig
from identity_tracker import IdentityTracker, TrackConfig
from online_labeler import OnlineLabeler, LabelConfig
from active_prober import ActiveProber, ProbeConfig

st.set_page_config(page_title="Real time neuron labeling demo", layout="wide")

def init():
    sim = NeuronSimulator(SimConfig(n_neurons=96, n_stim=8, n_state=4, dt_s=0.02, seed=3))
    tracker = IdentityTracker(TrackConfig(cost="cosine", max_cost=0.35, seed=3))
    labeler = OnlineLabeler(LabelConfig(n_stim=sim.cfg.n_stim, n_state=sim.cfg.n_state))
    prober = ActiveProber(ProbeConfig(n_stim=sim.cfg.n_stim, n_state=sim.cfg.n_state), rng_seed=3)
    return sim, tracker, labeler, prober

if "sim" not in st.session_state:
    st.session_state["sim"], st.session_state["tracker"], st.session_state["labeler"], st.session_state["prober"] = init()
    st.session_state["step"] = 0
    st.session_state["history"] = []

sim: NeuronSimulator = st.session_state["sim"]
tracker: IdentityTracker = st.session_state["tracker"]
labeler: OnlineLabeler = st.session_state["labeler"]
prober: ActiveProber = st.session_state["prober"]

st.title("Real time neuron labeling demo")

colA, colB, colC = st.columns([1,1,2])
with colA:
    run_steps = st.number_input("steps per run", min_value=10, max_value=2000, value=200, step=10)
with colB:
    sleep_ms = st.number_input("sleep ms", min_value=0, max_value=50, value=5, step=1)
with colC:
    st.write("This demo simulates a population with hidden tuning and shows live label vectors per tracked neuron id.")

btn1, btn2, btn3 = st.columns(3)
go = btn1.button("run")
reset = btn2.button("reset")
freeze = btn3.button("single step")

if reset:
    st.session_state.clear()
    st.experimental_rerun()

if go or freeze:
    n = 1 if freeze else int(run_steps)
    for _ in range(n):
        t = st.session_state["step"]
        stim = prober.choose_stim(labeler)
        state = prober.choose_state(labeler)
        movement = float(np.sin(t * 0.03) + 0.15 * np.random.randn())
        pkt = sim.step(stim, state, movement)
        stable_ids = tracker.match(pkt["features"])
        labeler.update(stable_ids, pkt["spikes"], stim, state, movement, sim.cfg.dt_s)
        st.session_state["step"] += 1
        if st.session_state["step"] % 10 == 0:
            snap = labeler.snapshot(top_n=30)
            if not snap.empty:
                st.session_state["history"].append({
                    "t_s": st.session_state["step"] * sim.cfg.dt_s,
                    "mean_stim_conf": float(snap["stim_conf"].mean()),
                    "mean_state_conf": float(snap["state_conf"].mean()),
                })
        if sleep_ms:
            time.sleep(float(sleep_ms) / 1000.0)

left, right = st.columns([2,1])

with left:
    st.subheader("Neuron label cards")
    snap = labeler.snapshot(top_n=40)
    st.dataframe(snap, use_container_width=True, hide_index=True)

with right:
    st.subheader("Run state")
    st.write(f"step: {st.session_state['step']}")
    if st.session_state["history"]:
        h = pd.DataFrame(st.session_state["history"])
        st.line_chart(h.set_index("t_s")[["mean_stim_conf", "mean_state_conf"]])
    st.caption("Confidence rises as the active prober samples informative stimuli and states.")
