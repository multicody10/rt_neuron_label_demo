\
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple
import numpy as np
from scipy.optimize import linear_sum_assignment

@dataclass
class TrackConfig:
    cost: str = "cosine"  # cosine or l2
    max_cost: float = 0.35
    seed: int = 1

class IdentityTracker:
    """
    Matches observed units across time to maintain stable ids.
    This is a stand in for the whole pipeline of spike sorting drift correction.

    Inputs are per unit feature vectors.
    Output is stable ids aligned to the current observed order.
    """
    def __init__(self, cfg: TrackConfig):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)
        self.prev_feat: Optional[np.ndarray] = None
        self.next_id: int = 0
        self.prev_ids: Optional[np.ndarray] = None

    def _cost_matrix(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        if self.cfg.cost == "l2":
            aa = (a ** 2).sum(axis=1, keepdims=True)
            bb = (b ** 2).sum(axis=1, keepdims=True).T
            return np.sqrt(np.maximum(aa + bb - 2.0 * (a @ b.T), 0.0))
        # cosine distance
        a_n = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-9)
        b_n = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-9)
        return 1.0 - (a_n @ b_n.T)

    def match(self, feat: np.ndarray) -> np.ndarray:
        feat = np.asarray(feat, dtype=np.float32)
        n = feat.shape[0]

        if self.prev_feat is None:
            ids = np.arange(self.next_id, self.next_id + n, dtype=np.int32)
            self.next_id += n
            self.prev_feat = feat
            self.prev_ids = ids
            return ids

        prev_feat = self.prev_feat
        prev_ids = self.prev_ids
        assert prev_ids is not None

        c = self._cost_matrix(prev_feat, feat)
        r, col = linear_sum_assignment(c)

        ids = np.full(n, -1, dtype=np.int32)
        used_prev = set()
        for i, j in zip(r.tolist(), col.tolist()):
            cost = float(c[i, j])
            if cost <= self.cfg.max_cost:
                ids[j] = int(prev_ids[i])
                used_prev.add(i)

        # Any unmatched gets new ids
        for j in range(n):
            if ids[j] < 0:
                ids[j] = self.next_id
                self.next_id += 1

        # Update memory by stable id ordering
        # We keep the current features and ids for next step
        self.prev_feat = feat
        self.prev_ids = ids
        return ids
