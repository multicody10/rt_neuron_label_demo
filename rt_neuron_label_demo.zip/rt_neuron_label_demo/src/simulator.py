\
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple, Dict, Any
import numpy as np

@dataclass
class SimConfig:
    n_neurons: int = 128
    n_stim: int = 8
    n_state: int = 4
    feat_dim: int = 12
    dt_s: float = 0.02
    seed: int = 1
    feature_drift: float = 0.004
    feature_noise: float = 0.02
    permute_each_step: bool = True

class NeuronSimulator:
    """
    Synthetic population with hidden true tuning.
    Output is intentionally shaped like an online pipeline:
    we provide drifting feature vectors plus spike counts per observed unit,
    with optional random permutation each step to force identity tracking.
    """
    def __init__(self, cfg: SimConfig):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)

        n = cfg.n_neurons
        k = cfg.n_stim
        m = cfg.n_state
        d = cfg.feat_dim

        # True feature vectors that drift slowly
        self.true_feat = self.rng.normal(0.0, 1.0, size=(n, d)).astype(np.float32)
        self.true_feat /= np.linalg.norm(self.true_feat, axis=1, keepdims=True) + 1e-9

        # Baseline firing rates in Hz
        self.base_hz = self.rng.lognormal(mean=np.log(3.0), sigma=0.35, size=(n,)).astype(np.float32)

        # Each neuron has a preferred stimulus and state, encoded as gain
        stim_pref = self.rng.integers(0, k, size=n)
        state_pref = self.rng.integers(0, m, size=n)
        self.stim_pref = stim_pref
        self.state_pref = state_pref

        stim_gain = self.rng.normal(0.0, 0.25, size=(n, k)).astype(np.float32)
        state_gain = self.rng.normal(0.0, 0.25, size=(n, m)).astype(np.float32)

        # Make one stim and one state stand out per neuron
        stim_gain[np.arange(n), stim_pref] += self.rng.uniform(0.8, 1.6, size=n).astype(np.float32)
        state_gain[np.arange(n), state_pref] += self.rng.uniform(0.5, 1.2, size=n).astype(np.float32)

        self.stim_gain = stim_gain
        self.state_gain = state_gain

        # Movement coupling
        self.move_gain = (self.rng.random(n) < 0.35).astype(np.float32) * self.rng.uniform(0.4, 1.2, size=n).astype(np.float32)

        self.t = 0

    def step(self, stim_idx: int, state_idx: int, movement: float) -> Dict[str, Any]:
        cfg = self.cfg
        n = cfg.n_neurons

        # Drift features
        drift = self.rng.normal(0.0, cfg.feature_drift, size=self.true_feat.shape).astype(np.float32)
        self.true_feat = self.true_feat + drift
        self.true_feat /= np.linalg.norm(self.true_feat, axis=1, keepdims=True) + 1e-9

        # Observed features: drifted true feat plus noise
        obs_feat = self.true_feat + self.rng.normal(0.0, cfg.feature_noise, size=self.true_feat.shape).astype(np.float32)
        obs_feat /= np.linalg.norm(obs_feat, axis=1, keepdims=True) + 1e-9

        # Rate model, ensure positive
        gain = self.stim_gain[:, stim_idx] + self.state_gain[:, state_idx] + self.move_gain * float(movement)
        rate_hz = self.base_hz * np.exp(gain.clip(-2.0, 2.0))
        lam = rate_hz * cfg.dt_s
        spikes = self.rng.poisson(lam=lam).astype(np.int32)

        order = np.arange(n)
        if cfg.permute_each_step:
            order = self.rng.permutation(n)

        self.t += 1
        return {
            "t": self.t,
            "stim_idx": int(stim_idx),
            "state_idx": int(state_idx),
            "movement": float(movement),
            "features": obs_feat[order],
            "spikes": spikes[order],
            "true_neuron_index": order,
            "truth": {
                "stim_pref": self.stim_pref.copy(),
                "state_pref": self.state_pref.copy(),
                "move_gain": self.move_gain.copy(),
                "base_hz": self.base_hz.copy(),
            },
        }
