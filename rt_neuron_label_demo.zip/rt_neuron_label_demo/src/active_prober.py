\
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

@dataclass
class ProbeConfig:
    n_stim: int
    n_state: int

class ActiveProber:
    """
    Chooses next stimulus and state to reduce uncertainty.
    For demo we score each stim by average entropy across tracked neurons,
    estimated from the labeler posterior proxy.
    """
    def __init__(self, cfg: ProbeConfig, rng_seed: int = 1):
        self.cfg = cfg
        self.rng = np.random.default_rng(rng_seed)

    def choose_stim(self, labeler) -> int:
        k = self.cfg.n_stim
        # If no data, explore
        if not labeler.total_time:
            return int(self.rng.integers(0, k))
        scores = np.zeros(k, dtype=np.float64)
        for nid in labeler.total_time.keys():
            spike = labeler.spike_stim[nid]
            time = labeler.time_stim[nid]
            rates = (spike + labeler.cfg.alpha) / (time + labeler.cfg.alpha)
            p = np.exp(np.log(rates + 1e-9) - np.max(np.log(rates + 1e-9)))
            p = p / (p.sum() + 1e-9)
            ent = -np.sum(p * np.log(p + 1e-9))
            # Encourage sampling of stims we have not seen much for this neuron
            w = 1.0 / (time + 0.05)
            scores += ent * w
        return int(np.argmax(scores))

    def choose_state(self, labeler) -> int:
        m = self.cfg.n_state
        if not labeler.total_time:
            return int(self.rng.integers(0, m))
        scores = np.zeros(m, dtype=np.float64)
        for nid in labeler.total_time.keys():
            time = labeler.time_state[nid]
            w = 1.0 / (time + 0.05)
            scores += w
        return int(np.argmax(scores))
