\
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple, Optional, List
import numpy as np
import pandas as pd

@dataclass
class LabelConfig:
    n_stim: int
    n_state: int
    alpha: float = 0.2
    eps: float = 1e-9

class OnlineLabeler:
    """
    Streaming label vector per neuron id:
    - stimulus preference distribution
    - state preference distribution
    - movement coupling score
    """
    def __init__(self, cfg: LabelConfig):
        self.cfg = cfg
        self.spike_stim: Dict[int, np.ndarray] = {}
        self.time_stim: Dict[int, np.ndarray] = {}
        self.spike_state: Dict[int, np.ndarray] = {}
        self.time_state: Dict[int, np.ndarray] = {}
        self.move_xy: Dict[int, Tuple[float, float, float]] = {}  # sum_x, sum_y, sum_x2 for corr proxy
        self.total_spikes: Dict[int, int] = {}
        self.total_time: Dict[int, float] = {}

    def _ensure(self, nid: int):
        k = self.cfg.n_stim
        m = self.cfg.n_state
        if nid not in self.spike_stim:
            self.spike_stim[nid] = np.zeros(k, dtype=np.float64)
            self.time_stim[nid] = np.zeros(k, dtype=np.float64)
            self.spike_state[nid] = np.zeros(m, dtype=np.float64)
            self.time_state[nid] = np.zeros(m, dtype=np.float64)
            self.move_xy[nid] = (0.0, 0.0, 0.0)
            self.total_spikes[nid] = 0
            self.total_time[nid] = 0.0

    def update(self, stable_ids: np.ndarray, spikes: np.ndarray, stim_idx: int, state_idx: int, movement: float, dt_s: float):
        stable_ids = np.asarray(stable_ids, dtype=np.int32)
        spikes = np.asarray(spikes, dtype=np.int32)
        for nid, s in zip(stable_ids.tolist(), spikes.tolist()):
            self._ensure(nid)
            self.spike_stim[nid][stim_idx] += s
            self.time_stim[nid][stim_idx] += dt_s
            self.spike_state[nid][state_idx] += s
            self.time_state[nid][state_idx] += dt_s

            sx, sy, sx2 = self.move_xy[nid]
            x = float(movement)
            y = float(s)
            self.move_xy[nid] = (sx + x, sy + y, sx2 + x * x)

            self.total_spikes[nid] += int(s)
            self.total_time[nid] += float(dt_s)

    def _rate(self, spike: np.ndarray, time: np.ndarray) -> np.ndarray:
        a = self.cfg.alpha
        return (spike + a) / (time + a)

    def _softmax(self, x: np.ndarray) -> np.ndarray:
        x = x - np.max(x)
        e = np.exp(x)
        return e / (np.sum(e) + self.cfg.eps)

    def _pref_and_conf(self, rates: np.ndarray) -> Tuple[int, float]:
        p = self._softmax(np.log(rates + self.cfg.eps))
        i = int(np.argmax(p))
        conf = float(p[i])
        return i, conf

    def _move_score(self, nid: int) -> float:
        # A very light proxy: if movement varies, score rises with spike covariance to movement
        sx, sy, sx2 = self.move_xy[nid]
        t = self.total_time.get(nid, 0.0)
        if t <= 0:
            return 0.0
        # movement mean and variance proxy assume movement in [-1,1]
        mx = sx / max(1.0, t / 0.02)
        vx = sx2 / max(1.0, t / 0.02) - mx * mx
        if vx <= 1e-6:
            return 0.0
        # crude slope proxy between movement and spikes
        mean_spk = self.total_spikes[nid] / max(1.0, t / 0.02)
        return float((mean_spk - 0.0) * mx / (np.sqrt(vx) + 1e-9))

    def snapshot(self, top_n: int = 25) -> pd.DataFrame:
        rows: List[Dict[str, object]] = []
        for nid in self.total_time.keys():
            stim_rates = self._rate(self.spike_stim[nid], self.time_stim[nid])
            state_rates = self._rate(self.spike_state[nid], self.time_state[nid])
            stim_pref, stim_conf = self._pref_and_conf(stim_rates)
            state_pref, state_conf = self._pref_and_conf(state_rates)
            hz = float(self.total_spikes[nid] / max(self.total_time[nid], 1e-9))
            rows.append({
                "id": int(nid),
                "rate_hz": hz,
                "stim_pref": stim_pref,
                "stim_conf": stim_conf,
                "state_pref": state_pref,
                "state_conf": state_conf,
                "move_score": self._move_score(nid),
            })
        df = pd.DataFrame(rows)
        if df.empty:
            return df
        df = df.sort_values(["stim_conf", "rate_hz"], ascending=False).head(top_n).reset_index(drop=True)
        return df
